export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  link: string;
  rating: number;
}

export const products = [
  {
    id: 1,
    name: 'Dyson HS05 Airwrap Complete hair dryer-brush 1300 W',
    price: 499790,
    description:
      'Type: Hair dryer-brush. Power, W: 1300, Additional modes: cold air supply. Included: brush attachment',
    link: 'https://kaspi.kz/shop/p/dyson-hs05-airwrap-complete-fen-schetka-1300-w-106790035/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hc5/h8c/63083544707102/dyson-hs05-airwrap-complete-fen-setka-1300-w-106790035-1.jpg',
    rating: 5,
  },
  {
    id: 2,
    name: 'Dyson HS05 hair dryer-brush 1300 W',
    price: 449890,
    description:
      'Type: Hair dryer-brush. Power, W: 1300. Construction: replaceable nozzles. Color: Blue',
    link: 'https://kaspi.kz/shop/p/dyson-hs05-fen-schetka-1300-w-108483916/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h3b/h3e/69147230666782/stailer-dyson-hs05-blue-rose-108483916-1.jpg',
    rating: 4.9,
  },
  {
    id: 3,
    name: 'Dyson HD07 hairdryer 1600 W',
    price: 379990,
    description: 'Type: Hair dryer. Power, W: 1600. Additional modes: cold air supply',
    link: 'https://kaspi.kz/shop/p/dyson-hd07-fen-1600-w-108611587/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hc1/h73/68296592654366/dyson-hd07-supersonic-426081-01-fen-1600-w-108611587-1.jpg',
    rating: 4.9,
  },
  {
    id: 4,
    name: 'Dyson Corrale HS03 ironing',
    price: 356780,
    description: 'Type: hair ironing. Power, W: 55. Design: display. Coating of nozzles: tourmaline',
    link: 'https://kaspi.kz/shop/p/dyson-corrale-hs03-utjuzhok-100321800/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h82/hca/32679119257630/dyson-corrale-hs03-fuksia-nikel-100321800-1-Container.jpg',
    rating: 4.7,
  },
  {
    id: 5,
    name: 'Dyson HD07 Supersonic Nickel Cooper hairdryer 1600 W',
    price: 357990,
    description: 'Type: Hair dryer. Power, W: 1600. Additional modes: ionization, cold air supply',
    link: 'https://kaspi.kz/shop/p/dyson-hd07-supersonic-nickel-cooper-fen-1600-w-106653069/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hc7/haa/62834707955742/fen-dyson-hd07-supersonic-nickel-cooper-106653069-1.jpg',
    rating: 5,
  },
  {
    id: 6,
    name: 'Dyson HD08 Blue-Copper hairdryer 1600 W',
    price: 409990,
    description: 'Type: Hair dryer. Power, W: 1600. Additional modes: ionization, ,cold air supply. Construction: replaceable nozzles. Color: Blue, Copper',
    link: 'https://kaspi.kz/shop/p/dyson-hd08-blue-copper-fen-1600-w-108433915/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h29/h36/67861282390046/fen-dyson-hd08-blue-copper-with-box-108433915-1.jpg',
    rating: 4.5,
  },
  {
    id: 7,
    name: 'Dyson HD08 Fuscia-Nickel hairdryer 1600 W',
    price: 399720,
    description: 'Type: Hair dryer. Power, W: 1600. Included: diffuser nozzle, hair straightening nozzle, concentrator nozzle, brush nozzle, nozzle for gentle drying',
    link: 'https://kaspi.kz/shop/p/dyson-hd08-fuscia-nickel-fen-1600-w-108433923/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h88/h46/67861294448670/fen-dyson-hd08-fuscia-nickel-108433923-1.jpg',
    rating: 4.9,
  },
  {
    id: 8,
    name: 'Dyson HD08 Prussian Blue hairdryer 1600 W',
    price: 399730,
    description: 'Type: Hair dryer. Power, W: 1600. Included: diffuser nozzle, ,concentrator nozzle. Construction: replaceable nozzles. Color: Blue',
    link: 'https://kaspi.kz/shop/p/dyson-hd08-prussian-blue-fen-1600-w-108434450/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h33/h77/67862653599774/fen-dyson-hd08-prussian-blue-108434450-1.jpg',
    rating: 4.85,
  },
  {
    id: 9,
    name: 'Dyson HD07 Supersonic Red hairdryer 1600 W',
    price: 379990,
    description: 'Type: Hair dryer. Power, W: 1600. Construction: replaceable nozzles. Color: Red. Country of origin: Malaysia',
    link: 'https://kaspi.kz/shop/p/dyson-hd07-supersonic-red-fen-1600-w-108041859/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h36/h21/66893979680798/fen-dyson-hd07-supersonic-red-108041859-1.jpg',
    rating: 4.73,
  },
  {
    id: 10,
    name: 'Dyson HD08 Prussian Blue hairdryer 1600 W',
    price: 399730,
    description: 'Type: Hair dryer. Power, W: 1600. Included: diffuser nozzle, ,concentrator nozzle. Construction: replaceable nozzles. Color: Blue',
    link: 'https://kaspi.kz/shop/p/dyson-hd08-prussian-blue-fen-1600-w-108434450/?c=750000000#!/item',
    image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h33/h77/67862653599774/fen-dyson-hd08-prussian-blue-108434450-1.jpg',
    rating: 4.1,
  },
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
